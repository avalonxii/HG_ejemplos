package com.base;

public class Turismo extends Vehiculo{
	
	private  int numPuertas;

	//constructor
	public Turismo(String matricula, String marca, String modelo, int numPuertas) {
		super(matricula, marca, modelo);
		this.numPuertas = numPuertas;
	}

	//getter / setters
	public int getNumPuertas() {
		return numPuertas;
	}

	public void setNumPuertas(int numPuertas) {
		this.numPuertas = numPuertas;
	}

	//metodos
	//sobreescrito
	public void mostrarDatos() {
		System.out.println("Matriculo: "+matricula+
							"\nMarca: "+marca+
							"\nModelo: "+modelo+ 
							"\nPuertas: "+numPuertas);
	}

}//cierre clase
