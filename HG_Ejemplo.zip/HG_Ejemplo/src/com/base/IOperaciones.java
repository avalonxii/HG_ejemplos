package com.base;

public interface IOperaciones {

	public int saltar();
	
}
