package com.base;

public class Hija extends Padre implements IOperaciones {
	//atributos propios de la clase hija
	private float peso;
	private int tlf;
	
	//constructor de una clase que hereda
	public Hija(String nombre, int edad, boolean casado, float peso, int tlf) {
		super(nombre, edad, casado);
		this.peso = peso;
		this.tlf = tlf;
	}
	
	//getter / setters
	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}

	public int getTlf() {
		return tlf;
	}

	public void setTlf(int tlf) {
		this.tlf = tlf;
	}
	
	//metodos
	
	@Override //metodo sobre escrito de la clase Padre 
	public void saludar() {
		System.out.println("Saludar desde Hija");
	}
	
	//Overload distinto numero de argumentos  
	public void saludar(String ciudad,int km) {
		System.out.println("Saludar desde Hija desde "+ciudad+" a "+km+"km de casa.");
	}
	
	//Overload distinto tipo de argumentos
	public void saludar(String ciudad,float km) {
		System.out.println("Saludar desde Hija desde "+ciudad+" a "+km+"km de casa.");
	}
	
	//Override de metodo de la interfaz
	public int saltar(){
		return 12;
	}
	
	/*
	public String saludar() {
		return "Saludar desde Hija" ;
	}*/
	
}
