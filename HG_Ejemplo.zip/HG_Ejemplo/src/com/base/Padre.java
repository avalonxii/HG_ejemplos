package com.base;

public abstract class Padre{
	//Atributos
	private String nombre;
	private int edad;
	private boolean casado;
	
	//constructor
	public Padre(String nombre, int edad, boolean casado) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.casado = casado;
	}
	
	//getters / setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public boolean isCasado() {
		return casado;
	}

	public void setCasado(boolean casado) {
		this.casado = casado;
	}
	
	//metodo
	public void saludar() {
		System.out.println("Saludar desde padre");
	}
	
}//cierra clase 
