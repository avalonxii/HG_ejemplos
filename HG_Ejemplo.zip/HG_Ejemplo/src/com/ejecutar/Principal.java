package com.ejecutar;

import com.base.*;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Hija hija1 = new Hija("Maria",23,false,50,645897123); 
		
		
		
		
	}

}
